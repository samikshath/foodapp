package com.cybage.model;

public class DrinkOrder {

}
