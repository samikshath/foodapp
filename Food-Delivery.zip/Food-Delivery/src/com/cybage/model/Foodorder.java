package com.cybage.model;

public class Foodorder {
	
	private int foId;
	private int orderId;
	private int foodId;
	private int qty;
	private int total_price;
	
	public Foodorder() {
		// TODO Auto-generated constructor stub
	}
	
	public Foodorder(int foId, int orderId, int foodId, int qty, int total_price) {
		super();
		this.foId = foId;
		this.orderId = orderId;
		this.foodId = foodId;
		this.qty = qty;
		this.total_price = total_price;
	}
	@Override
	public String toString() {
		return "Foodorder [foId=" + foId + ", orderId=" + orderId + ", foodId=" + foodId + ", qty=" + qty
				+ ", total_price=" + total_price + "]";
	}
	public int getFoId() {
		return foId;
	}
	public void setFoId(int foId) {
		this.foId = foId;
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public int getFoodId() {
		return foodId;
	}
	public void setFoodId(int foodId) {
		this.foodId = foodId;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	public int getTotal_price() {
		return total_price;
	}
	public void setTotal_price(int total_price) {
		this.total_price = total_price;
	}
	

}
