package com.cybage.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.cybage.model.Food;
import com.cybage.service.FoodOrderServiceImpl;
import com.cybage.service.IFoodOrderService;
import com.cybage.service.IOrderService;
import com.cybage.service.OrderServiceImpl;

/**
 * Servlet implementation class OrderController
 */
@WebServlet("/OrderController")
public class OrderController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private IOrderService orderService= new OrderServiceImpl();
	private IFoodOrderService foodOrderService=new FoodOrderServiceImpl();
	
	 
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public OrderController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int foodId=Integer.parseInt(request.getParameter("p"));
		
		Food food=orderService.addOrder(foodId);
		int order_id=foodOrderService.addFoodOrder(foodId);
		
		HttpSession session=request.getSession();
		session.setAttribute("food_id", food.getFoodId());
		session.setAttribute("food_name", food.getFoodName());
		session.setAttribute("food_price", food.getFoodPrice());
		session.setAttribute("order_id", order_id);
		
		
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

	/**
	 * @see HttpServlet#doDelete(HttpServletRequest, HttpServletResponse)
	 */
	protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
