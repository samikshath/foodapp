package com.cybage.service;

import com.cybage.model.Food;
import com.cybage.model.Foodorder;

public interface IOrderService {
	
	public Food addOrder(int foodId);

}
