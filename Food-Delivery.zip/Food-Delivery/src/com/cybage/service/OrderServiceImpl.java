package com.cybage.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cybage.model.Food;


import com.cybage.utility.JDBCUtility;


public class OrderServiceImpl implements IOrderService {
	
	Connection connection=JDBCUtility.getConnection();
	PreparedStatement preparedStatement=null;
	ResultSet resultSet= null;
	Food food=null;

	@Override
	public Food addOrder(int foodId) {
		try {
			preparedStatement=connection.prepareStatement("select * from food where food_id=?");
			preparedStatement.setInt(1, foodId);
			resultSet=preparedStatement.executeQuery();
			
			 while(resultSet.next()) {
				 food= new Food(resultSet.getInt(1), resultSet.getString(2), resultSet.getInt(3) 
						);
				 
			 }
			
			//connection.close();
			
			return food;
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return null;
		
	}
		

	}


