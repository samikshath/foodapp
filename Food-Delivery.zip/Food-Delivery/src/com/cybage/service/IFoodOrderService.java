package com.cybage.service;

public interface IFoodOrderService {
	
	public int addFoodOrder(int foodId);

}
