package com.cybage.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cybage.model.Food;
import com.cybage.model.Foodorder;
import com.cybage.utility.JDBCUtility;

public class FoodOrderServiceImpl implements IFoodOrderService {
	
	Connection connection=JDBCUtility.getConnection();
	PreparedStatement preparedStatement=null;
	ResultSet resultSet= null;
	Foodorder foodOrder=null;
	
	private IOrderService orderService= new OrderServiceImpl();
	
	private static int FO_idCounter = 1;
	private static int Order_idCounter = 1;
	public static synchronized int FO_createID()
	{
    	return FO_idCounter++;
	}
	public static synchronized int Order_createID()
	{
    	return Order_idCounter++;
	}

	
	public int addFoodOrder(int foodId) {
		
		try {
			preparedStatement=connection.prepareStatement("insert into foodOrder values(?,?,?,?,?)");
			
			foodOrder.setFoId(FO_createID());
   			foodOrder.setOrderId(Order_createID());
   			Food food=orderService.addOrder(foodId);
   			
   			preparedStatement.setInt(1, foodOrder.getFoId()); 
   			preparedStatement.setInt(2, foodOrder.getOrderId());				
   			preparedStatement.setInt(3, foodId);
   			preparedStatement.setInt(4, 1);
   			preparedStatement.setInt(5, food.getFoodPrice());
			
   			preparedStatement.executeUpdate(); 
			//connection.close();
			
			return foodOrder.getOrderId();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		return 0;
	}

}
